/* 
 * File:   adc.c
 * Author: brub9
 *
 * Created on 16 d�cembre 2024, 14:58
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
