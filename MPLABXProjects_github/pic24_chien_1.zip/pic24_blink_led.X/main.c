/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif


#include <stdint.h>        /* Includes uint16_t definition                    */
#include <stdbool.h>       /* Includes true/false definition                  */
#include <libpic30.h>
#include <stdio.h>      // Pour __delay_ms
#include "system.h"        /* System funct/params, like osc/peripheral config */
#include "user.h"          /* User funct/params, such as InitApp              */
#include "LCD.h"
#include "LCD_7seg.h"
#include "adc.h"
/******************************************************************************/
/* Global Variable Declaration                                                */
/******************************************************************************/

/* i.e. uint16_t <variable_name>; */

/******************************************************************************/
/* Main Program                                                               */
/******************************************************************************/
#define RA0 LATAbits.LATA0
    // COM
#define RE3 LATEbits.LATE3 // RE3_COM
#define RE2 LATEbits.LATE2 // RE2_COM
#define RE1 LATEbits.LATE1 // RE1_COM
#define RE0 LATEbits.LATE0 // RE0_COM
#define RF1 LATFbits.LATF1 // RF1_COM
#define RB10 LATBbits.LATB10 // RB10_COM
#define RB9 LATBbits.LATB9 //  RB9_COM
#define RB8 LATBbits.LATB8 //  TB8_COM
    // SEG
#define RF0 LATFbits.LATF0 // RF0_SEG27
#define RG1 LATGbits.LATG1 // RG1_SEG46
#define RG0 LATGbits.LATG0 // RG0_SEG50
#define RA6 LATAbits.LATA6 // RA6_SEG58
#define RA7 LATAbits.LATA7 // RA7_SEG59
#define RG12 LATGbits.LATG12 // RG12_SEG61
#define RG13 LATGbits.LATG13 // RG13_SEG62

char val1='X';
char val2='X';
char val3='X';
char val4='X';
char val5='X';

#define BUFFER_SIZE 16
uint16_t adcBuffer[BUFFER_SIZE];







void ADC_CustomInterruptHandler(void)
{
    // Lire les donn�es ADC ou ex�cuter une action sp�cifique
    ADC1_ConversionResultBufferGet(adcBuffer); // R�cup�re les r�sultats
    // Exemple : Affiche ou traite les donn�es
    for (int i = 0; i < BUFFER_SIZE; i++) {
        printf("ADC Value [%d]: %u\n", i, adcBuffer[i]);
    }
}



int16_t main(void)
{

    /* Configure the oscillator for the device */
    ConfigureOscillator();
    /* Initialize IO ports and peripherals */
    InitApp();
    
    
    
    // Initialisation de l'ADC
    ADC1_Initialize();
    // Configurer RB5/AN5
    AD1CSSLbits.CSS5 = 1;  // Activer AN5 pour le balayage
    TRISBbits.TRISB5 = 1;  // RB5 en entr�e
    
    
    
    // microchip
    LCD_Initialize();
    LCD_SetPowerMode(LCD_POWER_MODE_HIGH);
    LCD_CLEAR();
    LCD_MICROCHIP1_On();
    
    LCD_CHAR1_Print(val1);
    LCD_CHAR2_Print(val2);
    LCD_CHAR3_Print(val3);
    LCD_CHAR4_Print(val4);
    LCD_CHAR5_Print(val5);
    //LCD_DOT1_On();
    //LCD_DOT2_On();
    //LCD_DOT3_On();
    
    
    LCD_ModeSet(LCD_MODE_NORMAL);
    LCD_MICROCHIP1_AltOn();
    
    int num=0;
    while(1)
    {
        //__________________________________lcd
        //led
        delay_ms(1000);
        RA0 = 1;
        //num++;
        if (num > 12) num = 1;  // Limiter le cycle � 3 cas
        //alterne_val(num, &val1, &val2, &val3, &val4, &val5);
        //LCD_ECRITURE(num, val1, val2, val3, val4, val5);
        delay_ms(1000);
        //led
        RA0 = 0;
        
        
        
        
        //__________________________________ADC
        // D�marrer la conversion
        //AD1CON1bits.DONE = 0;
        ADC1_Start();
        // Attendre que la conversion soit termin�e
        while (!AD1CON1bits.DONE);       
        if (AD1CON1bits.DONE) {  // Si la conversion est termin�e
            //val1 = '1';          // Afficher '1'
            //val2 = '1';
            val3 = '1';
            //val4 = '1';
            //val5 = '1';
            
        } else {
            //val1 = '0';          // Sinon afficher '0'
            //val2 = '0';
            val3 = '0';
            //val4 = '0';
            //val5 = '0';
        }
        LCD_ECRITURE(num, val1, val2, val3, val4, val5);       
        // Lire la valeur du buffer pour AN5
        uint16_t adcValue = ADC1BUF0;
        Nop();
        
        // Convertir adcValue en cha�ne de caract�res (d�cimal)
        char adcValueStr[10];  // Assez de place pour un nombre de 16 bits
        sprintf(adcValueStr, "%u", adcValue);  // Convertit adcValue en cha�ne d�cimale

        // Variables pour stocker les chiffres
        char milDigit='X';
        char centDigit='X';
        char unitDigit='X'; 
        char tensDigit='X';

        // R�cup�rer les unit�s (le chiffre des unit�s)
        unitDigit = (char)(adcValue % 10);  // Le reste de la division par 10 donne les unit�s

        // R�cup�rer les dizaines (le chiffre des dizaines)
        tensDigit = (char)((adcValue / 10) % 10);  // Diviser par 10, puis prendre le reste pour obtenir les dizaines
        
        // R�cup�rer les centaines (le chiffre des centaines)
        centDigit = (char)((adcValue / 100) % 10);  // Diviser par 100, puis prendre le reste pour obtenir les centaines

        // R�cup�rer les milliers (le chiffre des milliers)
        milDigit = (char)((adcValue / 1000) % 10);  // Diviser par 1000, puis prendre le reste pour obtenir les milliers

        Nop();
        
        // Arr�ter l'ADC pour �viter les conversions inutiles
        ADC1_Stop();
        val1=milDigit + '0';
        val2=centDigit + '0';
        val3=tensDigit + '0';
        //LCD_DOT2_On();
        val4=unitDigit + '0';
        val5=' ';
        LCD_ECRITURE(num, val1, val2, val3, val4, val5); 
        delay_ms(1000);
        Nop();
        Nop();
        Nop();
    }

}


void alterne_val(int num, char *val1, char *val2, char *val3, char *val4, char *val5) { 
    // Gestion des diff�rents cas
    switch (num) {
        
        case 1:
            *val1 = 'S'; 
            *val2 = 'T'; 
            *val3 = 'A';      
            *val4 = 'R'; 
            *val5 = 'T'; 
            break;
        case 2:
            *val1 = '-'; 
            *val2 = 'C'; 
            *val3 = 'O'; 
            *val4 = '-'; 
            *val5 = '-'; 
            break;

        case 3:
            *val1 = '_'; 
            *val2 = '_'; 
            *val3 = '_';      
            *val4 = '_'; 
            *val5 = '%'; 
            break;

        case 4:
            *val1 = '-'; 
            *val2 = '0'; 
            *val3 = '2';      
            *val4 = '-'; 
            *val5 = '-'; 
            break;
            
        case 5:
            *val1 = '_'; 
            *val2 = '_'; 
            *val3 = '_';      
            *val4 = '_'; 
            *val5 = '%'; 
            break;

        case 6:
            *val1 = '-'; 
            *val2 = 'N'; 
            *val3 = 'O';      
            *val4 = '2'; 
            *val5 = '-'; 
            break;

        case 7:
            *val1 = '2'; 
            *val2 = '0'; 
            *val3 = '2';      
            *val4 = '4'; 
            *val5 = '%'; 
            break;
            
        case 8:
            *val1 = '-'; 
            *val2 = 'N'; 
            *val3 = 'H'; 
            *val4 = '3'; 
            *val5 = '-'; 
            break;

        case 9:
            *val1 = '_'; 
            *val2 = '_'; 
            *val3 = '_';      
            *val4 = '_'; 
            *val5 = '%'; 
            break; 

        case 10:
            *val1 = '-'; 
            *val2 = 'H'; 
            *val3 = '2';      
            *val4 = 'S'; 
            *val5 = '-'; 
            break;
            
              
        case 11:
            *val1 = '_'; 
            *val2 = '_'; 
            *val3 = '_';      
            *val4 = '_'; 
            *val5 = '%'; 
            break; 

        case 12:
            *val1 = '_'; 
            *val2 = 'F'; 
            *val3 = 'I';      
            *val4 = 'N'; 
            *val5 = '_'; 
            break;

        default:
            *val1 = *val2 = *val3 = *val4 = *val5 = '?';
            break;
    }
}

void LCD_ECRITURE(int num, char val1, char val2, char val3, char val4, char val5){
    
    if (num%2==1){
        LCD_CLEAR();
        LCD_MICROCHIP1_On();

        LCD_CHAR1_Print(val1);
        LCD_CHAR2_Print(val2);
        LCD_DOT2_On();
        LCD_CHAR3_Print(val3);
        LCD_CHAR4_Print(val4);
        LCD_CHAR5_Print(val5);

        LCD_ModeSet(LCD_MODE_NORMAL);
        LCD_MICROCHIP1_AltOn();
    }else{
        LCD_CLEAR();
        LCD_MICROCHIP1_On();

        LCD_CHAR1_Print(val1);
        LCD_CHAR2_Print(val2);
        LCD_CHAR3_Print(val3);
        LCD_CHAR4_Print(val4);
        LCD_CHAR5_Print(val5);

        LCD_ModeSet(LCD_MODE_NORMAL);
        LCD_MICROCHIP1_AltOn();
    }
    if (num==1)(LCD_DOT2_Off());

}


